﻿// Declaración de variables
string nombreEstudiante = "Juan Pérez";
decimal calificacionExamen1 = 85.5m;
decimal calificacionExamen2 = 92.0m;
decimal calificacionExamen3 = 78.5m;
decimal porcentajeAsistencia = 90m;

// Cálculo del promedio de exámenes
decimal promedioExamenes = (calificacionExamen1 + calificacionExamen2 + calificacionExamen3) / 3;

// Cálculo de la calificación final
// Calificación Final = (Promedio de Exámenes * 0.8) + (Porcentaje de Asistencia * 0.2)
decimal calificacionFinal = (promedioExamenes * 0.8m) + (porcentajeAsistencia * 0.2m);

// Impresión de resultados en consola
Console.WriteLine("======================================");
Console.WriteLine("    CALIFICACIÓN FINAL DEL ESTUDIANTE");
Console.WriteLine("======================================");
Console.WriteLine($"Nombre del estudiante: {nombreEstudiante}");
Console.WriteLine($"Calificación Examen 1: {calificacionExamen1}");
Console.WriteLine($"Calificación Examen 2: {calificacionExamen2}");
Console.WriteLine($"Calificación Examen 3: {calificacionExamen3}");
Console.WriteLine($"Promedio de exámenes: {promedioExamenes:F2}");
Console.WriteLine($"Porcentaje de asistencia: {porcentajeAsistencia}%");
Console.WriteLine("--------------------------------------");
Console.WriteLine($"Calificación Final: {calificacionFinal:F2}");
Console.WriteLine("======================================");
﻿using System;

class Program
{
    static void Main()
    {
        // Arreglos para almacenar hasta 3 estudiantes y sus notas
        string[] nombres = new string[3];
        double[][] calificaciones = new double[3][];
        int totalEstudiantes = 0;
        bool salir = false;

        // 1. Ciclo while para el menú principal
        while (!salir)
        {
            Console.Clear();
            Console.WriteLine("-REGISTRO DE CALIFICACIONES-");
            Console.WriteLine("1. Ingresar las calificaciones\n2. Ver Promedio de Calificaciones\n3. Salir");
            Console.Write("Seleccione una opción: ");

            // Validación de la opción del menú
            if (int.TryParse(Console.ReadLine(), out int opcion))
            {
                // 1. Estructura switch
                switch (opcion)
                {
                    case 1:
                        if (totalEstudiantes >= 3) { Console.WriteLine("\nMáximo 3 estudiantes alcanzado."); break; }
                        
                        Console.Write("Nombre del estudiante: ");
                        nombres[totalEstudiantes] = Console.ReadLine();

                        Console.Write("Cantidad de calificaciones: ");
                        if (int.TryParse(Console.ReadLine(), out int cant) && cant > 0)
                        {
                            calificaciones[totalEstudiantes] = new double[cant];
                            
                            // 2. Ciclo for para registrar calificaciones con validación robusta
                            for (int i = 0; i < cant; i++)
                            {
                                Console.Write($"  Nota {i + 1}: ");
                                while (!double.TryParse(Console.ReadLine(), out calificaciones[totalEstudiantes][i]))
                                    Console.Write("  [Error] Ingrese un valor numérico válido: ");
                            }
                            totalEstudiantes++;
                            Console.WriteLine("\n¡Estudiante registrado con éxito!");
                        }
                        break;

                    case 2:
                        Console.Write("Ingrese el nombre a buscar: ");
                        string buscado = Console.ReadLine();
                        
                        // 3. Buscar estudiante ignorando mayúsculas/minúsculas
                        int idx = Array.FindIndex(nombres, n => n != null && n.Equals(buscado, StringComparison.OrdinalIgnoreCase));

                        if (idx != -1)
                        {
                            double suma = 0;
                            foreach (double nota in calificaciones[idx]) suma += nota;
                            double promedio = suma / calificaciones[idx].Length;

                            Console.WriteLine($"\nEstudiante: {nombres[idx]} | Promedio: {promedio:F2}");
                        }
                        else
                        {
                            Console.WriteLine("\nEstudiante no encontrado.");
                        }
                        break;

                    case 3:
                        salir = true;
                        Console.WriteLine("\nSaliendo del programa...");
                        break;

                    default:
                        // Mensaje de error si la opción no es 1, 2 o 3
                        Console.WriteLine("\n[Error] Opción no válida.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("\n[Error] Entrada no válida.");
            }

            if (!salir)
            {
                Console.WriteLine("\nPresione cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}